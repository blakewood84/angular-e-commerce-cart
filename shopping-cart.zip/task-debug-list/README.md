create a method to splice any item with quantity of 0 and upload any remaining items to localStorage

FIX:
-Issue with Cart Prices ( not showing decimal .00 on some)
-Issue Product Display Rating (needs working method)



Add a Sorting Method for Price and Name
Add a Comments Section for Users
+ Bubble to Shopping Cart when products added
Only let user add up to ammount of product in stock

====FINISHED TASKS====
Fix Rating Function for View-Products
Swap broken images on error with default
Decide on Background Image
Style Hero on View Products
Github, LinkedIn Icons, Email Icon
Create Tests to Run **
Total for Cart Items
Delete style
Add Style
Style Product Detail Page
Buy Product Style
Add "Product Added" 
Product Rating function
Navbar Font Size and Color
put active class on menu item
Add to cart alert
Find Cart Icon to use
Style Navbar - font-size, colors
Put a background-image on Hero
put in correct links for social icons
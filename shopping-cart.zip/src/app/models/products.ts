export class Products {
    id:string;
    name: string;
    subtitle: string;
    description: string;
    price: string;
    instock: number;
    image_url: string;
    rating: string;
}

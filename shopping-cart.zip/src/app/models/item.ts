import { Products } from './products';

export class Item {
    product: Products;
    quantity: number;
}
